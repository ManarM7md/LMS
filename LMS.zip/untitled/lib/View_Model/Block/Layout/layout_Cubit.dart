import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/View/Pages/HomeScreen.dart';
import 'package:untitled/View/Pages/NewsScreen.dart';
import 'package:untitled/View/Pages/SettingScreen.dart';

part 'layout_State.dart';

class LayoutCubit extends Cubit<LayoutStates> {
  LayoutCubit() : super(LayoutInitialState());

  static LayoutCubit get(BuildContext context) => BlocProvider.of(context);
  List<Widget> list = [const HomePage(), const NewsScreen(), const SettingScreen()];
  int currentIndex = 0;

  void changeCurrent(int newIndex) {
    currentIndex = newIndex;
    emit(LayoutChange());
  }
}
