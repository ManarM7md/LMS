
abstract class TermsStates {}
 class TermsIntialState extends TermsStates{}
class TermsStoredData extends TermsStates{}

