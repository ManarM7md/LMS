abstract class SectionStates{}

class SectionInitial extends SectionStates{}

class SectionStoredData extends SectionStates{}