import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/View/Pages/LoginScreen.dart';
import 'package:untitled/View_Model/Block/SignUp/SignUP_State.dart';
import 'package:untitled/View_Model/Database/network/dio_helper.dart';
import '../../Database/network/end_points.dart';

class SignUpCubit extends Cubit<SignUpStates> {
  SignUpCubit() : super(SignUpInitial());

  static SignUpCubit get(BuildContext context) => BlocProvider.of(context);

  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController pass1 = TextEditingController();
  TextEditingController pass2 = TextEditingController();
  TextEditingController phone = TextEditingController();

  void signUser(BuildContext context) {
    var data = {
      "name": name.text,
      "email": email.text,
      "passwored": pass1.text,
      "re_passwored": pass2.text,
      "phone": phone.text
    };
    DioHelper.postData(url: registerEndPoint, data: data).then((value) {
      print(value.data);
      print(value.statusCode);
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const LoginScreen(),
          ));
    }).catchError((onError) {
      print(onError);
    });
  }
}
