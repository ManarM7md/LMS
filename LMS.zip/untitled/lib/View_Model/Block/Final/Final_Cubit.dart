
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/Constent.dart';
import 'package:untitled/Model/ExamModel.dart';
import 'package:untitled/View_Model/Block/Final/Final_States.dart';
import 'package:untitled/View_Model/Database/network/dio_helper.dart';
import 'package:untitled/View_Model/Database/network/end_points.dart';

class FinalCubit extends Cubit<FinalStates>
{
  FinalCubit() : super(FinaLInitial());
  static FinalCubit get(BuildContext context) =>BlocProvider.of(context);
  ExamModel? examModel;

  void getFinalData()
  {
    //var query ={"final": false};
    DioHelper.getData(url: examsEndPoint,token: token).then((value) {
      examModel = ExamModel.fromJson(value.data);
      print(examModel!.code);
      emit(FinaLStoredData());
    });
  }
}