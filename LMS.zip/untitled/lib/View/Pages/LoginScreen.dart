import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled/View/Component/Common/elevatedButton.dart';
import 'package:untitled/View/Component/LogIn_SignUp/deviderComponent.dart';
import 'package:untitled/View/Component/LogIn_SignUp/elevatedButtonWithBorder.dart';
import 'package:untitled/View/Component/Common/orangeLogoComponent.dart';
import 'package:untitled/View/Component/LogIn_SignUp/textFormField.dart';
import 'package:untitled/View/Component/LogIn_SignUp/textFormFieldWithIcon.dart';
import '../../View_Model/Block/LoginScreen/LoginCubit.dart';
import '../../View_Model/Block/LoginScreen/LoginState.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LoginCubit(),
      child: BlocConsumer<LoginCubit, LoginState>(
        listener: (context, state) {},
        builder: (context, state) {
          LoginCubit myCubit = LoginCubit.get(context);
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: ThemeData(primarySwatch: Colors.deepOrange),
            home: Scaffold(
              body: SafeArea(
                child: SingleChildScrollView(
                  child: Column(children: [
                    orangeLogo(),
                    const SizedBox(
                      height: 70,
                    ),
                    Container(
                      width: 350,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "Login",
                                style: GoogleFonts.poppins(
                                    fontSize: 25, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          textFormFiled('E-Mail', myCubit.emial),
                          textFormWithIcon(
                              'Password',
                              myCubit.password,
                              const Icon(
                                Icons.remove_red_eye,
                                color: Colors.deepOrange,
                              )),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "Forgot password?",
                                style: GoogleFonts.poppins(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w400,
                                    color: Colors.deepOrangeAccent,
                                    decoration: TextDecoration.underline),
                              ),
                            ],
                          ),
                          elevatedButton('Login', () {
                            myCubit.loginUser(context);
                          }),
                          divider(),
                          elevatedButtonBorder('Sign Up', false, context)
                        ],
                      ),
                    )
                  ]),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
