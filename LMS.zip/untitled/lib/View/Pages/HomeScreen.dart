import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled/View/Pages/EventScreen.dart';
import 'package:untitled/View/Pages/FinalScreen.dart';
import 'package:untitled/View/Pages/LectureScreen.dart';
import 'package:untitled/View/Pages/MidtermScreen.dart';
import 'package:untitled/View/Pages/NotesScreen.dart';
import 'package:untitled/View/Pages/SectionScreen.dart';
import '../Component/Home/HomeCartComponent.dart';
import 'package:flutter_svg/flutter_svg.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Column(children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Orange",
              style: GoogleFonts.poppins(
                  fontSize: 25,
                  fontWeight: FontWeight.w600,
                  color: Colors.deepOrangeAccent),
            ),
            Text(
              " Digital Center",
              style: GoogleFonts.poppins(
                  fontSize: 25, fontWeight: FontWeight.w600),
            ),
          ],
        ),
        const SizedBox(
          height: 30,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Column(
              children: [
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => LectureScreen())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/lecture.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Lectures"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => MidtermScreen())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/midterm.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Midterms"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => EventsScreen())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/event.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Events"),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
            const SizedBox(width: 15),
            Column(
              children: [
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => SectionScreen())),
                  child: homeCard(
                      SvgPicture.asset('assets/icons/sections.svg',
                          height: 35,
                          width: 30,
                          color: Colors.deepOrangeAccent),
                      "Sections"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => FinalScreen())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/final.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Finals"),
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => NotesScreen())),
                  child: homeCard(
                      SvgPicture.asset(
                        'assets/icons/notes.svg',
                        height: 35,
                        width: 30,
                      ),
                      "Notes"),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
          ],
        ),
      ]),
    ));
  }
}
