import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FAQ_Screen extends StatelessWidget {
  const FAQ_Screen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        home: Scaffold(
            body: SafeArea(
      child: SingleChildScrollView(
          child: Column(children: [
        const SizedBox(
          height: 20,
        ),
        Center(
          child: Row(//mainAxisAlignment: MainAxisAlignment.center,
              children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const SizedBox(
                  width: 10,
                ),
                InkWell(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    )),
              ],
            ),
            const SizedBox(
              width: 135,
            ),
            Text("FAQ",
                style: GoogleFonts.poppins(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    textStyle: const TextStyle(color: Colors.black)))
          ]),
        ),
        const SizedBox(height: 10),
        const Card(
          color: Colors.deepOrangeAccent,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(15), topRight: Radius.circular(15))),
          child: ExpansionTile(
            iconColor: Colors.white,
            textColor: Colors.white,
            title: Text(
              "Q1:How Many Countries Orange Digital Center Is In ? ",
              style: TextStyle(color: Colors.white),
            ),
            children: [
              Divider(thickness: .7),
              Card(
                  color: Colors.grey,
                  child: ListTile(
                    title: Text("16 Country",
                        style: TextStyle(color: Colors.white)),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(25),
                            bottomRight: Radius.circular(25))),
                  ))
            ],
          ),
        )
      ])),
    )));
  }
}
