import 'package:flutter/material.dart';
import 'package:untitled/View_Model/Database/network/dio_helper.dart';
import 'SplashScreen.dart';

void main() async {
  await DioHelper.init();
  runApp(const MaterialApp(debugShowCheckedModeBanner: false, home: splash()));
}
