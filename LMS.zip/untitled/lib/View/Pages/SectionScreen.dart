import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled/View/Pages/nev_barLayout.dart';
import 'package:untitled/View_Model/Block/Section/Section_Cubit.dart';
import 'package:untitled/View_Model/Block/Section/Section_States.dart';

import '../Component/Home/CardLectureComnent.dart';
class SectionScreen extends StatelessWidget {
  const SectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => SectionCubit()..getSectionData(),
        child: BlocConsumer<SectionCubit, SectionStates>(
            listener: (context, state) {},
            builder: (context, state) {
              SectionCubit sectionCubit = SectionCubit.get(context);
              return Scaffold(
                appBar: AppBar(
                  centerTitle: true,
                  backgroundColor: Colors.white,
                  leading: InkWell(
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const NevBarLayout())),
                      child: const Icon(
                        Icons.arrow_back_ios,
                        size: 24,
                        color: Colors.deepOrangeAccent,
                      )),
                  title: Text("Sections",
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        textStyle:
                            const TextStyle(color: Colors.black, letterSpacing: .5),
                      )),
                  actions: [
                    PopupMenuButton(
                        icon: const Icon(
                          Icons.filter_alt,
                          color: Colors.deepOrange,
                        ),
                        itemBuilder: (context) => [
                              PopupMenuItem(
                                value: 1,
                                child: Text("All Sections",
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black,
                                          letterSpacing: .5),
                                    )),
                              ),
                              PopupMenuItem(
                                value: 2,
                                child: Text("Finished Sections",
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black,
                                          letterSpacing: .5),
                                    )),
                              ),
                              PopupMenuItem(
                                value: 2,
                                child: Text("Remaining Sections",
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400,
                                      textStyle: const TextStyle(
                                          color: Colors.black,
                                          letterSpacing: .5),
                                    )),
                              )
                            ]),
                  ],
                ),
                body: Container(
                    child: sectionCubit.sectionModel == null
                        ? const Center(
                            child: Center(
                                child: CircularProgressIndicator(
                                    color: Colors.deepOrangeAccent)),
                          )
                        : ListView.builder(
                            shrinkWrap: true,
                            itemCount: sectionCubit.sectionModel!.data!.length,
                            itemBuilder: (context, index) {
                              return lectureCard(
                                  sectionCubit
                                      .sectionModel!.data![index].sectionSubject
                                      .toString(),
                                  sectionCubit
                                      .sectionModel!.data![index].sectionDate
                                      .toString(),
                                  sectionCubit.sectionModel!.data![index]
                                      .sectionStartTime
                                      .toString(),
                                  sectionCubit
                                      .sectionModel!.data![index].sectionEndTime
                                      .toString());
                            },
                          )),
              );
            }));
  }
}
