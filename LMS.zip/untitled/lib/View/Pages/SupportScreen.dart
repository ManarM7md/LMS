import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled/View/Component/Common/elevatedButton.dart';
import 'package:untitled/View/Component/Support/textformfiedComponent.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
          leading: InkWell(
              onTap: () => Navigator.pop(context),
              child:
                  const Icon(Icons.arrow_back_ios, color: Colors.deepOrangeAccent)),
          centerTitle: true,
          backgroundColor: Colors.white,
          title: Text(
            "Support",
            style: GoogleFonts.poppins(
              fontSize: 25,
              fontWeight: FontWeight.w600,
              color: Colors.black,
            ),
          )),
      body: Column(children: [
        textFormFiledSupport("Name", const Icon(Icons.person)),
        textFormFiledSupport("E-Mail", const Icon(Icons.email)),
        Container(
          margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          width: 350,
          child: TextFormField(
            minLines: 6,
            maxLines: 8,
            keyboardType: TextInputType.multiline,
            decoration: InputDecoration(
              hintText: "What's makeing you unhappy?",
              fillColor: Colors.grey[200],
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
          ),
        ),
        elevatedButton(
          "Submit",
          () {},
        )
      ]),
    );
  }
}
