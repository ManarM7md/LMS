import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Widget divider() {
  return Row(
    mainAxisAlignment: MainAxisAlignment.start,
    children: const [
      Expanded(
          child: Divider(
        color: Colors.black,
        thickness: 1,
      )),
      SizedBox(width: 9),
      Text(
        "OR",
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
      ),
      SizedBox(width: 9),
      Expanded(
          child: Divider(
        color: Colors.black,
        thickness: 1,
      )),
    ],
  );
}
