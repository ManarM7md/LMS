import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget elevatedButton(String text, Function() navigator) {
  return Container(
    width: 350,
    height: 45,
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(50)),
    margin: const EdgeInsets.fromLTRB(0, 30, 0, 20),
    child: ElevatedButton(
      onPressed: navigator,
      style: const ButtonStyle(
        backgroundColor:
            MaterialStatePropertyAll<Color>(Colors.deepOrangeAccent),
      ),
      child: Text(
        text,
        style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600),
      ),
    ),
  );
}
