import 'package:flutter/material.dart';

Widget textFormFiledSupport(String txt, Icon icon) {
  return Container(
    margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
    width: 350,
    child: TextFormField(
      obscureText: true,
      decoration: InputDecoration(
        labelText: txt,
        prefixIcon: icon,
        fillColor: Colors.grey[200],
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    ),
  );
}
