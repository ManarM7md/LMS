import 'package:flutter/material.dart';

Widget list(String text, Icon icon, Function() move) {
  return ListTile(
    title: Text(text),
    trailing: icon,
    onTap: move,
  );
}
